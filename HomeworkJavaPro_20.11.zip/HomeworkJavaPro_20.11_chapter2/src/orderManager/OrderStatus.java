package orderManager;

public enum OrderStatus {
    DELIVERED,
    CANCELED,
    IN_PROCESS
}
